﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFNgApp.Models;

namespace EFNgApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        EmployeeDataAccessLayer objemployee = new EmployeeDataAccessLayer();

        //// GET: api/Employee
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET: api/Employee/5
        [HttpGet("{id}", Name = "Get")]
        public EmployeeModel Get(int id)
        {
            EmployeeModel employee = objemployee.GetEmployeeById(id);
            employee.countryList = objemployee.GetCountrys();
            employee.stateList = objemployee.GetStateByCountry(employee.country);
            employee.cityList = objemployee.GetCities().Where(x => x.stateid == employee.state).ToList(); ;
            return employee;
        }

        // POST: api/Employee
        [HttpPost]
        public int SaveEmployee([FromBody] EmployeeModel employee)
        {
            objemployee.SaveEmployee(employee);
            return 1;
        }

        //// GET: api/Employee
        [HttpGet]
        public IEnumerable<EmployeeModel> Get()
        {
            IEnumerable<EmployeeModel> lstEmployeeDetails = objemployee.GetEmployees();
            return lstEmployeeDetails;
        }

        // PUT: api/Employee/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
