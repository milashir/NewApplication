﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFNgApp.Models;

namespace EFNgApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StateController : ControllerBase
    {
        EmployeeDataAccessLayer objemployee = new EmployeeDataAccessLayer();

        // GET: api/State
        [HttpGet]
        public IEnumerable<TblState> Get()
        {
            return objemployee.GetStates();
        }

        //GET: api/State/5
        [HttpGet("{id}", Name = "GetState")]
        public IEnumerable<TblState> Get(int id)
        {
            EmployeeModel employee = new EmployeeModel();
            List<TblState> lstState= objemployee.GetStateByCountry(id);
            return lstState;
        }

    }
}
