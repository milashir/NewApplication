﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFNgApp.Models;

namespace EFNgApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        EmployeeDataAccessLayer objemployee = new EmployeeDataAccessLayer();

        // GET: api/Country
        [HttpGet]
        public IEnumerable<TblCountry> Get()
        {
            return objemployee.GetCountrys();
        }

    }
}
