﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFNgApp.Models;

namespace EFNgApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobController : ControllerBase
    {
        PortalDataAccessLayer objPortal = new PortalDataAccessLayer();

        // GET: api/Job
        [HttpGet]
        public IEnumerable<JobsAvailableModel> Get()
        {
            IEnumerable<JobsAvailableModel> lstInterestingJobs = objPortal.GetInterestingJobs();
            return lstInterestingJobs;
        }

        //// GET: api/Job/5
        //[HttpGet("{id}", Name = "Get")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST: api/Job
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT: api/Job/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE: api/ApiWithActions/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
