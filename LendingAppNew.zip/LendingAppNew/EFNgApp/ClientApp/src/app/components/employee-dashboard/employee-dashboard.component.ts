import { Component, Inject } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../../services/employeeservice.service';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent {
  public employeeList: employeeData[];

  constructor(public http: Http, private _router: Router, private _employeeService: EmployeeService) {
    this.getEmployees();
  }

  getEmployees() {
    this._employeeService.getEmployees().subscribe(
      data => this.employeeList = data
    )
  }
}

interface employeeData {
  firstname: string;
  middlename: string;
  lastname: string;
  gender: string;
  dob: string;
  streetaddress1: string;
  streetaddress2: string;
  country: string;
  state: string;
  city: string;
  zip: string;
  selectedskills: string;
}



