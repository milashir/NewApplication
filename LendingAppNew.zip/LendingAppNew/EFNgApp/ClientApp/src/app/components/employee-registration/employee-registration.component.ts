import { Component, OnInit } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { NgForm, FormBuilder, FormGroup, FormArray, Validators, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../../services/employeeservice.service';
import { AbstractControl } from '@angular/forms';
import { zipValidator } from '../../services/customvalidators';

@Component({
  selector: 'app-employee-registration',
  templateUrl: './employee-registration.component.html',
  styleUrls: ['./employee-registration.component.css']
})

export class EmployeeRegistrationComponent implements OnInit {
  employeeForm: FormGroup;
  title: string = "Create";
  errorMessage: any;
  data: any;
  countryList: Array<any> = [];
  stateList: Array<any> = [];
  cityList: Array<any> = [];
  employeeId: number;
  employeeData: any;
  result: any = [];
  i: number = 1;


  public minDate: Date = new Date("05/07/2017");
  public maxDate: Date = new Date("05/27/2017");
  public value: Date = new Date("05/16/2017");

  skills = ["Asp.Net", "C#", "Sql Server", "JavaScript"];

  constructor(private _fb: FormBuilder, private _avRoute: ActivatedRoute,
    private _employeeService: EmployeeService, private _router: Router) {

    if (this._avRoute.snapshot.params["id"]) {
      this.employeeId = this._avRoute.snapshot.params["id"];
    }

    this.employeeForm = this._fb.group({
      id: 0,
      firstname: '',
      middlename: '',
      lastname: '',
      gender: '',
      dob:'',
      streetaddress1: '',
      streetaddress2: '',
      country: '',      
      state: '',
      city: '',
      zip: ['', [Validators.required, zipValidator]],
      selectedskills: '',
    })
  }

 

  ngOnInit() {

    if (this.employeeId > 0) {
      this.getEmployeesById(this.employeeId);

      //this._employeeService.getStateList().subscribe(
      //  data => this.stateList = data
      //)

      //this._employeeService.getCityList().subscribe(
      //  data => this.cityList = data
      //)   
    }

    this._employeeService.getCountryList().subscribe(
      data => this.countryList = data
    )     

    
  }

  save() {


    //for (var i = 0; i <= this.skills.length; i++) {
    //  alert(this.skills[i]);
    //}

    if (!this.employeeForm.valid) {
      return;
    }  

    this._employeeService.saveEmployee(this.employeeForm.value)
        .subscribe((data) => {
          this._router.navigate(['/employee-dashboard']);
        }, error => this.errorMessage = error)
   
  }

  getEmployeesById(id: number) {
    this._employeeService.getEmployeeById(id)
      .subscribe(resp => this.employeeForm.setValue(resp)
      , error => this.errorMessage = error);

    this._employeeService.getEmployeeById(id)
      .subscribe(
        data => this.employeeData = data
        )
  }

  getStateByCountry(id: number) {
    this._employeeService.getStateByCountry(id).subscribe(
      data => this.stateList = data
    )
  }

  getStateByCountryEdit(id: number) {
    this._employeeService.getStateByCountry(id).subscribe(
      data => this.employeeData.stateList = data
    )
  }

  getCityByState(id: number) {
    this._employeeService.getCityByState(id).subscribe(
      data => this.cityList = data
    )
  }

  getCityByStateEdit(id: number) {
    this._employeeService.getCityByState(id).subscribe(
      data => this.employeeData.cityList = data
    )
  }

  selectedSkills: Array<any> = [];
  
  onChangeSkill(value) {
    if (this.i == 1) {
      this.selectedSkills = (<HTMLInputElement>document.getElementById('hdnSelectedSkills')).value.split(',');
    }   
    if ((<HTMLInputElement>document.getElementById(value)).checked === true) {      
        this.selectedSkills.push(value);
    }
    else if ((<HTMLInputElement>document.getElementById(value)).checked === false) {
      let indexx = this.selectedSkills.indexOf(value);
      this.selectedSkills.splice(indexx, 1)
    }     
    (<HTMLInputElement>document.getElementById('hdnSelectedSkills')).value = this.selectedSkills.join(",");
    this.employeeForm.controls["selectedskills"].setValue(((<HTMLInputElement>document.getElementById('hdnSelectedSkills')).value));
    this.i++;
  } 


  //get id() { return this.employeeForm.get('id'); }
 // get firstname() { return this.employeeForm.get('firstname'); }
  //get middlename() { return this.employeeForm.get('middlename'); }
  //get lastname() { return this.employeeForm.get('lastname'); }
  //get streetaddress1() { return this.employeeForm.get('streetaddress1'); }
  //get streetaddress2() { return this.employeeForm.get('streetaddress2'); }
  //get city() { return this.employeeForm.get('city'); }
  //get state() { return this.employeeForm.get('state'); }
  get zip() { return this.employeeForm.get('zip'); }
  get selectedskills() { return this.employeeForm.get('selectedskills'); }
  get countries(): FormArray {
    return this.employeeForm.get('countries') as FormArray;
  }
}





