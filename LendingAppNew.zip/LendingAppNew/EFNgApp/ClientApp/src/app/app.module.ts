import { NgModule } from '@angular/core';
import { InvestmentService } from './services/investmentservice.service'
import { EmployeeService } from './services/employeeservice.service'
import { JobService } from './services/jobservice.service'

import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { AddInvestmentComponent } from './components/add-investment/add-investment.component';
import { HomeComponent } from './home/home.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { AppComponent } from './app.component';
import { BrowserModule } from '@angular/platform-browser';
import { EmployeeRegistrationComponent } from './components/employee-registration/employee-registration.component';
import { EmployeeDashboardComponent } from './components/employee-dashboard/employee-dashboard.component';
import { DatePickerModule } from '@syncfusion/ej2-angular-calendars';
 

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    AddInvestmentComponent,
    EmployeeRegistrationComponent,
    EmployeeDashboardComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    DatePickerModule,
    CommonModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule, 
    RouterModule.forRoot([
        { path: '', component: HomeComponent, pathMatch: 'full' },
        { path: 'home', component: HomeComponent },  
      { path: 'add-investment', component: AddInvestmentComponent },
      { path: 'investment/add/:id', component: AddInvestmentComponent },
      { path: 'employee-registration', component: EmployeeRegistrationComponent },
      { path: 'employee-registration/:id', component: EmployeeRegistrationComponent },
      { path: 'employee-dashboard', component: EmployeeDashboardComponent },
        { path: '**', redirectTo: 'home' }  
    ])
  ], 
  providers: [InvestmentService, EmployeeService, JobService],
  bootstrap: [AppComponent]
})
export class AppModule { }
