﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public class PortalDataAccessLayer
    {
        //To Get the list of Interesting Jobs  
        public List<JobsAvailableModel> GetInterestingJobs()
        {
            List<JobsAvailableModel> lstJobs = new List<JobsAvailableModel>();
            JobsAvailableModel job1 = new JobsAvailableModel();
            job1.id = 1;
            job1.position = "C # developers (eg .NET, .NET Core, ASP.NET MVC, WPF, SharePoint, ...)";
            job1.company = "eWorks GmbH";
            job1.companyimage = "//media.stepstone.com/upload_de/logo/E/logoeWorks-GmbH-44208DE.gif";
            job1.jobposted = "20 hours ago";
            job1.location = "Frankfurt am Main";
            lstJobs.Add(job1);
            JobsAvailableModel job2 = new JobsAvailableModel();
            job2.id = 2;
            job2.position = "Senior Software Developer (m / w / d) for .NET";
            job2.company = "msg systems ag";
            job2.companyimage = "//media.stepstone.com/upload_de/logo/M/logomsg-systems-ag-5245DE.gif";
            job2.jobposted = "1 day ago";
            job2.location = "Berlin, Essen, Frankfurt am Main, Hamburg, Cologne";
            lstJobs.Add(job2);
            JobsAvailableModel job3 = new JobsAvailableModel();
            job3.id = 2;
            job3.position = "Software Developer (m / f) C # / .NET";
            job3.company = "FEV Software and Testing Solutions GmbH";
            job3.companyimage = "//media.stepstone.com/upload_de/logo/7/logoFEV-Software-and-Testing-Solutions-GmbH-218504DE.gif";
            job3.jobposted = "2 weeks ago";
            job3.location = "Aachen, Landsberg (near Leipzig)";
            lstJobs.Add(job3);
            return lstJobs;
        }
    }
}
