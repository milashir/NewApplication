﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public class Language
    {
        public int languageid;
        public string languagename;
    }
}
