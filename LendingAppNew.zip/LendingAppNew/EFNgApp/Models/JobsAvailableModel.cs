﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public partial class JobsAvailableModel
    {
        public int id;
        public string position;
        public string company;
        public string companyimage;
        public string jobposted;
        public string location;       
    }
}
