﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public class EmployeeDataAccessLayer
    {
        //To Get the list of Employees  
        public List<EmployeeModel> GetEmployees()
        {
            List<EmployeeModel> lstEmployee = new List<EmployeeModel>();
            EmployeeModel employee1 = new EmployeeModel();
            employee1.id=1;
            employee1.firstname="aa";
            employee1.middlename="bb";
            employee1.lastname="cc";
            employee1.gender="Male";
            employee1.dob=DateTime.Now;
            employee1.streetaddress1="dd";
            employee1.streetaddress2="ee";
            employee1.country=1;
            employee1.state=1;
            employee1.city=1;
            employee1.zip="22222";
            employee1.selectedskills="Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee1);
            EmployeeModel employee2 = new EmployeeModel();
            employee2.id = 2;
            employee2.firstname = "aa1";
            employee2.middlename = "bb1";
            employee2.lastname = "cc1";
            employee2.gender = "Female";
            employee2.dob = DateTime.Now.AddDays(1);
            employee2.streetaddress1 = "dd1";
            employee2.streetaddress2 = "ee1";
            employee2.country = 2;
            employee2.state = 3;
            employee2.city = 3;
            employee2.zip = "22222";
            employee2.selectedskills = "Sql Server";
            lstEmployee.Add(employee2);
            return lstEmployee;
        }

        //To Get the list of Employees  
        public EmployeeModel GetEmployeeById(int id)
        {
            List<EmployeeModel> lstEmployee = GetEmployees();            
            return lstEmployee.Where(x=>x.id==id).ToList().FirstOrDefault();
        }

        //To Get the list of Country  
        public List<TblCountry> GetCountrys()
        {
            List<TblCountry> lstCountry = new List<TblCountry>();
            TblCountry country1 = new TblCountry();
            country1.countryid = 1;
            country1.countryname = "India";
            lstCountry.Add(country1);
            TblCountry country2 = new TblCountry();
            country2.countryid = 2;
            country2.countryname = "Germany";
            lstCountry.Add(country2);
            return lstCountry;
        }


        //To Get the list of Cities  
        public List<TblCities> GetCities()
        {
            List<TblCities> lstCity = new List<TblCities>();
            TblCities city1 = new TblCities();
            city1.cityid = 1;
            city1.cityname = "Calicut";
            city1.stateid = 1;
            lstCity.Add(city1);
            TblCities city2 = new TblCities();
            city2.cityid = 2;
            city2.cityname = "Cochin";
            city2.stateid = 1;
            lstCity.Add(city2);
            TblCities city3 = new TblCities();
            city3.cityid = 3;
            city3.cityname = "Berlin";
            city3.stateid = 3;
            lstCity.Add(city3);
            TblCities city4 = new TblCities();
            city4.cityid = 4;
            city4.cityname = "Munich";
            city4.stateid = 4;
            lstCity.Add(city4);
            return lstCity;
        }

        //To Get the list of States  
        public List<TblState> GetStates()
        {
            List<TblState> lstState = new List<TblState>();
            TblState state1 = new TblState();
            state1.stateid = 1;
            state1.statename = "Kerala";
            state1.countryid = 1;
            lstState.Add(state1);
            TblState state2 = new TblState();
            state2.stateid = 2;
            state2.statename = "Karnataka";
            state2.countryid = 1;
            lstState.Add(state2);
            TblState state3 = new TblState();
            state1.stateid = 3;
            state1.statename = "Berlin";
            state1.countryid = 2;
            lstState.Add(state3);
            TblState state4 = new TblState();
            state2.stateid = 4;
            state2.statename = "Bremen";
            state2.countryid = 2;
            lstState.Add(state4);
            return lstState;
        }


        //To Get the list of States by country  
        public List<TblState> GetStateByCountry(int countryId)
        {
            List<TblState> lstState = new List<TblState>();
            TblState state1 = new TblState();
            state1.stateid = 1;
            state1.statename = "Kerala";
            state1.countryid = 1;
            lstState.Add(state1);
            TblState state2 = new TblState();
            state2.stateid = 2;
            state2.statename = "Karnataka";
            state2.countryid = 1;
            lstState.Add(state2);
            TblState state3 = new TblState();
            state3.stateid = 3;
            state3.statename = "Berlin";
            state3.countryid = 2;
            lstState.Add(state3);
            TblState state4 = new TblState();
            state4.stateid = 4;
            state4.statename = "Bremen";
            state4.countryid = 2;
            lstState.Add(state4);
            return lstState.Where(x => x.countryid == countryId).ToList();
        }

        //To Get the list of Cities by state  
        public List<TblCities> GetCityByState(int stateId)
        {            
            List<TblCities> lstCity = new List<TblCities>();
            TblCities city1 = new TblCities();
            city1.cityid = 1;
            city1.cityname = "Calicut";
            city1.stateid = 1;
            city1.countryid = 1;
            lstCity.Add(city1);
            TblCities city2 = new TblCities();
            city2.cityid = 2;
            city2.cityname = "Cochin";
            city2.stateid = 1;
            city2.countryid = 1;
            lstCity.Add(city2);
            TblCities city3 = new TblCities();
            city3.cityid = 3;
            city3.cityname = "Berlin";
            city3.stateid = 3;
            city3.countryid = 2;
            lstCity.Add(city3);
            TblCities city4 = new TblCities();
            city4.cityid = 4;
            city4.cityname = "Munich";
            city4.stateid = 4;
            city4.countryid = 2;
            lstCity.Add(city4);
            return lstCity.Where(x=>x.stateid==stateId).ToList();
        }

        public void SaveEmployee(EmployeeModel employee)
        {
            if (employee.id > 0)
            {
            }
            else
            {
            }
        }
    }
}
