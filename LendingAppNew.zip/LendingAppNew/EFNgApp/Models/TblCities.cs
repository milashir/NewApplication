﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public partial class TblCities
    {
        public int cityid { get; set; }
        public string cityname { get; set; }
        public int stateid { get; set; }
        public int countryid { get; set; }
    }
}
